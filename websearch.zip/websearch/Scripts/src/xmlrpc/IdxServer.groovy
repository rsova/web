package xmlrpc
import groovy.net.xmlrpc.*
import java.net.ServerSocket
//http://repository.codehaus.org/org/codehaus/groovy/groovy-xmlrpc/0.8/
class IdxServer {
//	def server = new XMLRPCServer()
//	server.echo = {return it}
}
